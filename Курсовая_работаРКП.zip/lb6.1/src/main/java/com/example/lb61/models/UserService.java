package com.example.lb61.models;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;


import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public void setUserRepository(UserRepository
                                             userRepository) {
        this.userRepository = userRepository;
    }
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
    public User getUserById(Long id) {
        return userRepository.findOne(id);
    }
    public User getUserByLogin(String login) {
        return userRepository.findOne(login);
    }
    public void deleteUserById(Long id) {
        userRepository.delete(id.toString());
    }
    public boolean saveUser(User user){
        return userRepository.save(user);
    }

    public boolean checkLogin(String login){
        return  userRepository.checkLogin(login);
    }
    public boolean checkEmail(String email){
        return  userRepository.checkEmail(email);
    }
    public boolean checkPhone(String phone){
        return  userRepository.checkPhone(phone);
    }

    public interface EmailService {
        public void sendSimpleEmail(
                String toAddress, String subject, String message);
    }
}
