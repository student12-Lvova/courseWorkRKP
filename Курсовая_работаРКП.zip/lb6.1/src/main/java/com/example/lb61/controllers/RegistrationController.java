package com.example.lb61.controllers;

import com.example.lb61.models.User;
import com.example.lb61.models.UserRepository;
import com.example.lb61.models.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Conditional;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.context.request.WebRequest;

import java.util.Map;

@Controller
public class RegistrationController {

    String errorLogin = "Ошибка ввода логина!";
    String errorUnicLogin = "Данный логин уже занят!";
    String errorPassword = "Ошибка ввода пароля!";
    String errorEmail = "Ошибка ввода email!";
    String errorUnicEmail = "Данный email уже занят!";
    String errorUnicPhone = "Данный номера телефона уже занят!";
    @Autowired
    private UserService userService;

    @GetMapping("/registration")
    public String registration(Model model) {
            model.addAttribute("userForm", new User());

        return "registration";
    }

    @PostMapping("/registration")
    public String addUser(@ModelAttribute("userForm") User user, BindingResult bindingResult, Model model) {
        if (user.getLogin()==null || user.getLogin().equals("")){
            model.addAttribute("user", user);
            model.addAttribute("errorLogin", errorLogin);
            return "registration";
        }
        if (!userService.checkLogin(user.getLogin())){
            model.addAttribute("user", user);
            model.addAttribute("errorLogin", errorUnicLogin);
            return "registration";
        }
        if (user.getPassword()==null || user.getPassword().equals("")){
            model.addAttribute("user", user);
            model.addAttribute("errorPassword", errorPassword);
            return "registration";
        }
        if (user.getEmail()==null || user.getEmail().equals("")){
            model.addAttribute("user", user);
            model.addAttribute("errorEmail", errorEmail);
            return "registration";
        }
        if (!userService.checkEmail(user.getEmail())){
            model.addAttribute("user", user);
            model.addAttribute("errorEmail", errorUnicEmail);
            return "registration";
        }
        if (!user.getPhoneNum().equals("") && !userService.checkPhone(user.getPhoneNum())){
            model.addAttribute("user", user);
            model.addAttribute("errorPhone", errorUnicPhone);
            return "registration";
        }

        user.setRole("USER");
        if (bindingResult.hasErrors()) {
            return "registration";
        }
        if (!userService.saveUser(user)){
            model.addAttribute("usernameError", "Пользователь с таким именем уже существует");
            return "registration";
        }



        return "redirect:/about";
    }
}
