package com.example.lb61.models.news;

import com.example.lb61.models.User;
import com.example.lb61.models.UserRepository;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class NewMapper implements RowMapper<New> {
    private final JdbcTemplate jdbcTemplate;
    private UserRepository userRepository;

    public NewMapper(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
        this.userRepository = new UserRepository(jdbcTemplate);
    }

    @Override
    public New mapRow(ResultSet rs, int rowNum) throws SQLException {
        New aNew = new New();
        aNew.setId(Long.valueOf(rs.getString("id")));
        aNew.setName(rs.getString("name"));
        aNew.setDesc(rs.getString("description"));
        aNew.setDate(LocalDate.parse(rs.getString("date")));
        aNew.setImage(rs.getString("image"));
        aNew.setUser(userRepository.findOne(Long.valueOf(rs.getString("idUser"))));
        return aNew;
    }
}