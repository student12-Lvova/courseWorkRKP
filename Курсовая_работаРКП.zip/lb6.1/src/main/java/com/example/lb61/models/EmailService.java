package com.example.lb61.models;

import org.springframework.stereotype.Service;

@Service
public interface EmailService {
    public void sendSimpleEmail(
            String toAddress, String subject, String message);
}
