package com.example.lb61.models.news;

import com.example.lb61.models.Article;
import com.example.lb61.models.CommentArticle;
import com.example.lb61.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NewService {
    private NewRepository newRepository;
    @Autowired
    public void setNewRepository(NewRepository
                                         newRepository) {
        this.newRepository = newRepository;
    }
    public List<New> getAllNews() {
        return newRepository.findAll();
    }
    public New getNewById(Long id) {
        return newRepository.findOne(id);
    }
    public void deleteNewById(Long id) {
        newRepository.delete(id.toString());
    }
    public void saveNew(New aNew){
        newRepository.save(aNew);
    }
    public List<CommentNews> getCommentsNew(Long id){
        return newRepository.findNewById(id);
    }
    public void saveCommentNew(CommentNews comment) {
        newRepository.saveComment(comment);
    }

    public List<Article> getAllArticles() {
        return newRepository.findAllArticle();
    }
    public Article getArticleById(Long id) {return newRepository.findOneArticle(id);}
    public void deleteArticleById(Long id) {
        newRepository.deleteArticle(id.toString());
    }
    public void saveArticle(Article article){
        newRepository.saveArticle(article);
    }
    public List<CommentArticle> getCommentsArticle(Long id){
        return newRepository.findArticleById(id);
    }
    public void saveCommentArticle(CommentArticle comment) {
        newRepository.saveCommentArticle(comment);
    }
}
