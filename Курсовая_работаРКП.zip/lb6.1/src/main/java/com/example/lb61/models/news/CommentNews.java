package com.example.lb61.models.news;

import com.example.lb61.models.User;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

public class CommentNews {

    private Long id;
    private New aNew;
    private User user;
    private  String textCom;
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME, fallbackPatterns = { "dd.MM.yyyy hh:mm" })
    private LocalDate date;


    public CommentNews(Long id, New aNew, User user, String textCom, LocalDate date) {
        this.id = id;
        this.aNew = aNew;
        this.user = user;
        this.textCom = textCom;
        this.date = date;
    }

    public CommentNews() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public New getaNew() {
        return aNew;
    }

    public void setaNew(New aNew) {
        this.aNew = aNew;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getTextCom() {
        return textCom;
    }

    public void setTextCom(String textCom) {
        this.textCom = textCom;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }
}
