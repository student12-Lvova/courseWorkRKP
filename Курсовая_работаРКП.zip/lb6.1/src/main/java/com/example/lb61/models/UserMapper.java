package com.example.lb61.models;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class UserMapper  implements RowMapper<User> {
    private final JdbcTemplate jdbcTemplate;

    public UserMapper(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public User mapRow(ResultSet rs, int rowNum) throws SQLException {
        User user = new User();
        user.setId(Long.valueOf(rs.getString("id")));
        user.setLogin(rs.getString("login"));
        String login = rs.getString("login");
        user.setPassword(rs.getString("password"));
        user.setEmail(rs.getString("email"));
        user.setPhoneNum(rs.getString("phoneNum"));
        user.setRole(jdbcTemplate.queryForObject(
                "SELECT authority FROM authorities where username = '"
                        + login + "'", new Object[] {}, String.class));
        return user;
    }
}

