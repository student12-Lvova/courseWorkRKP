package com.example.lb61.models.news;

import com.example.lb61.models.User;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;

public class New {
    private Long id;
    private  String name;
    private  String desc;
    private LocalDate date;
    private String image;
    private User user;
    private MultipartFile file;

    public MultipartFile getFile() {
        return file;
    }

    public void setFile(MultipartFile file) {
        this.file = file;
    }

    public New() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public New(Long id, String name, String desc, LocalDate date, String image, User user) {
        this.id = id;
        this.name = name;
        this.desc = desc;
        this.date = date;
        this.image = image;
        this.user = user;
    }
}
