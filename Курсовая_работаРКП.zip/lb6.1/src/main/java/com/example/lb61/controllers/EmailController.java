package com.example.lb61.controllers;

import com.example.lb61.models.EmailService;
import com.example.lb61.models.User;
import com.example.lb61.models.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("")
public class EmailController {
    @Autowired
    EmailService emailService;
    @Autowired
    private UserService userService;

    @GetMapping(value = "/email/{id}")
    public @ResponseBody ResponseEntity sendSimpleEmail(
            @PathVariable("id") String idUser) {
        try {
            User user = userService.getUserById(Long.valueOf(idUser));
            emailService.sendSimpleEmail(
                    user.getEmail(),
                    "Вас зарегестрировали на сайте volleyballNews.ru!",
                    "Вы являетесь журналистом нашего сайта!\n" +
                            "Ваш логин: " + user.getLogin() + "\nВаш пароль: " + user.getPassword() +
                            "\nДля входа в аккаунт!");
        } catch (MailException mailException) {
            return new ResponseEntity<>(
                    "Невозможно отправить почту",
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }
        return new ResponseEntity<>(
                "Письмо успешно отправлено.",
                HttpStatus.OK
        );
    }
}
