package com.example.lb61.models;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
@Repository
public class UserRepository {
    private final JdbcTemplate jdbcTemplate;
    public UserRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
    public List<User> findAll(){
        return jdbcTemplate.query("Select * from users;", new UserMapper(jdbcTemplate));
    }
    public User findOne(Long id) {
        User student =
                jdbcTemplate.queryForObject("select * from users where id = ?",
                        new Object[]{id}, new UserMapper(jdbcTemplate));
        return student;
    }
    public User findOne(String login) {
        User student = student =
                jdbcTemplate.queryForObject("select * from users where login = ?",
                        new Object[]{login}, new UserMapper(jdbcTemplate));
        return student;
    }
    public boolean save(User user) {
            if (user.getId() == null) {
                jdbcTemplate.update("insert into users (login,password,email,phoneNum,enabled) values (?,?,?,?,?) ",
                        user.getLogin(), user.getPassword(), user.getEmail(), user.getPhoneNum(), true);
                if (user.getRole().equals(""))
                    jdbcTemplate.update("insert into authorities values (?,?) ",
                        user.getLogin(), "NEWSMAN");
                else
                    jdbcTemplate.update("insert into authorities values (?,?) ",
                            user.getLogin(), user.getRole());
            } else {
                jdbcTemplate.update("update users set login = ?, password = ?, email=?, phoneNum=? where id = ?",
                        user.getLogin(), user.getPassword(), user.getEmail(), user.getPhoneNum(), user.getId());

            }
            return true;
    }
    private boolean checkData(String login, String email, String phone){
        List<User> count = new ArrayList<>();
        if (!phone.equals("")) {
        count = jdbcTemplate.query("select * from users where login = ? or email = ? or phoneNum = ?",
                new Object[]{login, email, phone}, new UserMapper(jdbcTemplate));
        }
        else{
            count = jdbcTemplate.query("select * from users where login = ? or email = ?",
                    new Object[]{login, email}, new UserMapper(jdbcTemplate));
        }
        if(count.size()>0)
            return false;
        else return true;
    }

     public boolean checkLogin(String login){
        List<User> count = jdbcTemplate.query("select * from users where login = ?",
                new Object[]{login}, new UserMapper(jdbcTemplate));
        if(count.size()>0)
            return false;
        else return true;
    }
    public boolean checkEmail(String email){
        List<User> count = jdbcTemplate.query("select * from users where email = ?",
                new Object[]{email}, new UserMapper(jdbcTemplate));
        if(count.size()>0)
            return false;
        else return true;
    }
    public boolean checkPhone(String phone){
        List<User> count = jdbcTemplate.query("select * from users where phoneNum = ?",
                new Object[]{phone}, new UserMapper(jdbcTemplate));
        if(count.size()>0)
            return false;
        else return true;
    }

    public int delete(String id) {
        jdbcTemplate.update("delete from authorities where username = ?", findOne(Long.valueOf(id)).getLogin());
        return jdbcTemplate.update(" delete from users where id = ?", id);
    }


}
