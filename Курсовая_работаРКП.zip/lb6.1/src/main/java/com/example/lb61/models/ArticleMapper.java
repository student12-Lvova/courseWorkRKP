package com.example.lb61.models;

import com.example.lb61.models.news.New;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class ArticleMapper implements RowMapper<Article> {
    private final JdbcTemplate jdbcTemplate;
    private UserRepository userRepository;

    public ArticleMapper(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
        this.userRepository = new UserRepository(jdbcTemplate);
    }

    @Override
    public Article mapRow(ResultSet rs, int rowNum) throws SQLException {
        Article article = new Article();
        article.setId(Long.valueOf(rs.getString("id")));
        article.setName(rs.getString("name"));
        article.setDesc(rs.getString("description"));
        article.setDate(rs.getDate("date").toLocalDate());
        article.setImage(rs.getString("image"));
        article.setUser(userRepository.findOne(Long.valueOf(rs.getString("idUser"))));
        return article;
    }
}
