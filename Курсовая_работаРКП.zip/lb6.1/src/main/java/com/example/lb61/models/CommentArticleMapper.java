package com.example.lb61.models;

import com.example.lb61.models.news.CommentNews;
import com.example.lb61.models.news.NewRepository;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class CommentArticleMapper implements RowMapper<CommentArticle> {
    private final JdbcTemplate jdbcTemplate;
    private UserRepository userRepository;
    private NewRepository newRepository;

    public CommentArticleMapper(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
        this.userRepository = new UserRepository(jdbcTemplate);
        this.newRepository = new NewRepository(jdbcTemplate);
    }

    @Override
    public CommentArticle mapRow(ResultSet rs, int rowNum) throws SQLException {
        CommentArticle commentArticle = new CommentArticle();
        commentArticle.setId(Long.valueOf(rs.getString("id")));
        commentArticle.setArticle(newRepository.findOneArticle(Long.valueOf(rs.getString("idArt"))));
        commentArticle.setUser(userRepository.findOne(Long.valueOf(rs.getString("idUser"))));
        commentArticle.setTextCom(rs.getString("textCom"));
        commentArticle.setDate(rs.getDate("date").toLocalDate());
        return commentArticle;
    }
}
