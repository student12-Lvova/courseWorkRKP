package com.example.lb61;

import com.example.lb61.models.UserRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;

@RestController
public class ApiController {
    final UserRepository ur;

    public ApiController(UserRepository ur) {
        this.ur = ur;
    }
    @GetMapping("/api")
    public String Welcome(@RequestParam(required = false,
            defaultValue = "Unknown User") String name, Principal principal)
    {
        return name + " : You are logged in as " +
                principal.getName() + ".";
    }

}