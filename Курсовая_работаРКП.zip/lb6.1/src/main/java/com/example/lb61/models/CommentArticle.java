package com.example.lb61.models;

import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

public class CommentArticle {
    private Long id;
    private Article article;
    private User user;
    private  String textCom;
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME, fallbackPatterns = { "dd.MM.yyyy hh:mm" })
    private LocalDate date;


    public CommentArticle(Long id, Article aNew, User user, String textCom, LocalDate date) {
        this.id = id;
        this.article = aNew;
        this.user = user;
        this.textCom = textCom;
        this.date = date;
    }

    public CommentArticle() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Article getArticle() {
        return article;
    }

    public void setArticle(Article article) {
        this.article = article;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getTextCom() {
        return textCom;
    }

    public void setTextCom(String textCom) {
        this.textCom = textCom;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }
}
