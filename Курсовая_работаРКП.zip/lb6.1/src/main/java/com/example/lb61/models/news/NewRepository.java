package com.example.lb61.models.news;

import com.example.lb61.models.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class NewRepository {
    private final JdbcTemplate jdbcTemplate;
    public NewRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }


    public List<New> findAll(){
        return jdbcTemplate.query("Select * from news;", new NewMapper(jdbcTemplate));
    }
    public List<CommentNews> findNewById(Long id) {
        List<CommentNews> comments = new ArrayList<>();
        comments = jdbcTemplate.query("Select * from commentsnews where idNew = ?;",new Object[]{id}, new CommentNewsMapper(jdbcTemplate));
        return comments;
    }
    public New findOne(Long id) {
        New aNew =
                jdbcTemplate.queryForObject("select * from news where id = ?",
                        new Object[]{id}, new NewMapper(jdbcTemplate));
        return aNew;
    }
    public void save(New aNew) {
        if (aNew.getId() == null) {
            jdbcTemplate.update("insert into news (idUser, name, description, date, image) values (?,?,?,?,?) ",
                    aNew.getUser().getId(), aNew.getName(), aNew.getDesc(), aNew.getDate(), aNew.getImage());
        } else {
            jdbcTemplate.update("update news set idUser = ?, name = ?, description=?, date=?, image=? where id = ?",
                    aNew.getUser().getId(), aNew.getName(), aNew.getDesc(), aNew.getDate(), aNew.getImage(),
                    aNew.getId());

        }
    }
    public int delete(String id) {
        jdbcTemplate.update(" delete from commentsnews where idNew = ?", id);
        return jdbcTemplate.update(" delete from news where id = ?", id);
    }

    public void saveComment(CommentNews comment) {
        jdbcTemplate.update("insert into commentsnews (idUser, idNew, textCom, date) values (?,?,?,?) ",
                comment.getUser().getId(), comment.getaNew().getId(), comment.getTextCom(), comment.getDate());
        //ыы

    }

    public List<Article> findAllArticle(){
        return jdbcTemplate.query("Select * from articles;", new ArticleMapper(jdbcTemplate));
    }
    public List<CommentArticle> findArticleById(Long id) {
        List<CommentArticle> comments = new ArrayList<>();
        comments = jdbcTemplate.query("Select * from commentsarticle where idArt = ?;",new Object[]{id}, new CommentArticleMapper(jdbcTemplate));
        return comments;
    }
    public Article findOneArticle(Long id) {
        Article article =
                jdbcTemplate.queryForObject("select * from articles where id = ?",
                        new Object[]{id}, new ArticleMapper(jdbcTemplate));
        return article;
    }
    public void saveArticle(Article article) {
        if (article.getId() == null) {
            jdbcTemplate.update("insert into articles (idUser, name, description, date, image, nameTeam1, nameTeam2) " +
                            "values (?,?,?,?,?,?,?) ",
                    article.getUser().getId(), article.getName(), article.getDesc(), article.getDate(),
                    article.getImage(), article.getNameTeam1() , article.getNameTeam2());
        } else {
            jdbcTemplate.update("update articles set idUser = ?, name = ?, description=?, date=?, image=? " +
                            "nameTeam1=?, nameTeam2=? where id = ?",
                    article.getUser().getId(), article.getName(), article.getDesc(), article.getDate(),
                    article.getImage(), article.getNameTeam1() , article.getNameTeam2(), article.getId());

        }
    }
    public int deleteArticle(String id) {
        jdbcTemplate.update(" delete from commentsarticle where idArt = ?", id);
        return jdbcTemplate.update(" delete from articles where id = ?", id);
    }

    public void saveCommentArticle(CommentArticle comment) {
        jdbcTemplate.update("insert into commentsarticle (idUser, idArt, textCom, date) values (?,?,?,?) ",
                comment.getUser().getId(), comment.getArticle().getId(), comment.getTextCom(), comment.getDate());
        //ыы

    }
}
