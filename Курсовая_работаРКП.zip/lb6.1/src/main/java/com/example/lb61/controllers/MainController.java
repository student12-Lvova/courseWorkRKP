package com.example.lb61.controllers;

import com.example.lb61.models.*;
import com.example.lb61.models.news.CommentNews;
import com.example.lb61.models.news.New;
import com.example.lb61.models.news.NewService;
import org.apache.tomcat.util.http.fileupload.impl.SizeException;
import org.apache.tomcat.util.http.fileupload.impl.SizeLimitExceededException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Principal;
import java.time.LocalDate;
import java.util.*;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

@Controller
public class MainController {
    //ошибки
    String errorLogin = "Ошибка ввода логина!";
    String errorUnicLogin = "Данный логин уже занят!";
    String errorPassword = "Ошибка ввода пароля!";
    String errorEmail = "Ошибка ввода email!";
    String errorUnicEmail = "Данный email уже занят!";
    String errorPhone = "Ошибка ввода номера телефона!";
    String errorUnicPhone = "Данный номера телефона уже занят!";


    String errorName = "Ошибка ввода названия!";
    String errorDate = "Ошибка ввода даты!";
    String errorNameT1 = "Ошибка ввода команды 1!";
    String errorNameT2 = "Ошибка ввода команды 2!";
    String errorScoreT1 = "Ошибка ввода результата команды 1!";
    String errorScoreT2 = "Ошибка ввода результата команды 2!";



    private UserService userService;
    private NewService newService;
    @Autowired
    EmailService emailService;

    @GetMapping("/about")
    public String mainForm(@RequestParam(value = "name", required=false, defaultValue = "Unnamed") String name, Model model, Principal principal){

        if (principal!=null)
            model.addAttribute("user", userService.getUserByLogin(principal.getName()));
        else model.addAttribute("user", new User());
        return "about";
    }
    @GetMapping("/")
    public String indexForm(@RequestParam(value = "name", required=false, defaultValue = "Unnamed") String name, Model model, Principal principal){
        if (principal!=null)
            model.addAttribute("user", userService.getUserByLogin(principal.getName()));
        else model.addAttribute("user", new User());
         return "index";
    }
    @GetMapping("/index")
    public String indexForm1(@RequestParam(value = "name", required=false, defaultValue = "Unnamed") String name, Model model, Principal principal){
        if (principal!=null)
            model.addAttribute("user", userService.getUserByLogin(principal.getName()));
        else model.addAttribute("user", new User());
        return "index";
    }

    //работа с пользователями
    @Autowired
    public void setUserService(UserService userService){
        this.userService = userService;
    }
    @GetMapping("/users")
    public String allUsers(@RequestParam(value = "name", required=false, defaultValue = "Unnamed") String name, Model model, Principal principal){
        if (!principal.getName().contains("admin")) return "redirect:/about";

        List<User> allUsers =
                userService.getAllUsers();
        List<User> userForAdmin = new ArrayList<>();
        for (var user : allUsers) {
            if (!user.getLogin().equals(principal.getName()) && user.getRole().equals("NEWSMAN")){
                userForAdmin.add(user);
            }
        }model.addAttribute("user", userService.getUserByLogin(principal.getName()));
        model.addAttribute("users", userForAdmin);
        return "users";
    }
    @GetMapping("/addUser")
    public String addUserForm(Model model, Principal principal){
        User user = new User();

        model.addAttribute("user", user);
        model.addAttribute("curUser", userService.getUserByLogin(principal.getName()));
        return "addUser";
    }
    @PostMapping("/addUser")
    public String addUserForm (@ModelAttribute User user, Model model){
        if (user.getLogin()==null || user.getLogin().equals("")){
            model.addAttribute("user", user);
            model.addAttribute("errorLogin", errorLogin);
            return "addUser";
        }
        if (!userService.checkLogin(user.getLogin())){
            model.addAttribute("user", user);
            model.addAttribute("errorLogin", errorUnicLogin);
            return "addUser";
        }
        if (user.getPassword()==null || user.getPassword().equals("")){
            model.addAttribute("user", user);
            model.addAttribute("errorPassword", errorPassword);
            return "addUser";
        }
        if (user.getEmail()==null || user.getEmail().equals("")){
            model.addAttribute("user", user);
            model.addAttribute("errorEmail", errorEmail);
            return "addUser";
        }
        if (!userService.checkEmail(user.getEmail())){
            model.addAttribute("user", user);
            model.addAttribute("errorEmail", errorUnicEmail);
            return "addUser";
        }
        if (!user.getPhoneNum().equals("") && !userService.checkPhone(user.getPhoneNum())){
            model.addAttribute("user", user);
            model.addAttribute("errorPhone", errorUnicPhone);
            return "addUser";
        }

        if(userService.saveUser(user)){
            User user1 = userService.getUserByLogin(user.getLogin());

            model.addAttribute("user", user);
            //отправляем на почту
            sendSimpleEmail(user1);

            return "redirect:/users";
        }
        else return "addUser";
    }
    public @ResponseBody ResponseEntity sendSimpleEmail(
            User user) {
        try {
            emailService.sendSimpleEmail(
                    user.getEmail(),
                    "Вас зарегестрировали на сайте volleyballNews.ru!\n",
                    "Вы являетесь журналистом нашего сайта!\n" +
                            "Ваш логин: " + user.getLogin() + "\nВаш пароль: " + user.getPassword() +
                            "\nДля входа в аккаунт!");
        } catch (MailException mailException) {
            return new ResponseEntity<>(
                    "Невозможно отправить почту",
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }
        return new ResponseEntity<>(
                "Письмо успешно отправлено.",
                HttpStatus.OK
        );
    }
    @GetMapping("/users/delete/{id}")
    public String deleteStudentById(@PathVariable("id") Long id){
        userService.deleteUserById(id);
        return "redirect:/users";
    }

    //профиль
    @GetMapping("/profile/{id}")
    public String profileForm(Model model, @PathVariable("id") Long id, Principal principal){
        User user;
        if (id!=null)
            user = userService.getUserById(id);
        else
            user = userService.getUserByLogin(principal.getName());

        if(user.getLogin().equals(principal.getName())){
            model.addAttribute("user", user);
            model.addAttribute("role", user.getRole());
            return "profile";
        }
        model.addAttribute("user", user);
        model.addAttribute("role", user.getRole());
        return  "redirect:/about";


    }
    @PostMapping("/profile/{id}")
    public String profileForm (@ModelAttribute User user, Model model, @PathVariable("id") Long id, Principal principal){
        User oldUser = userService.getUserById(id);

        model.addAttribute("user", user);
        model.addAttribute("cur_user", userService.getUserById(id));
        model.addAttribute("role", user.getRole());

        user.setLogin(oldUser.getLogin());
        if (user.getPassword().equals(oldUser.getPassword()) && !user.getNewPassword().equals(""))
            user.setPassword(user.getNewPassword());
        else{
            user.setPassword(oldUser.getPassword());
        }
        if (!user.getEmail().equals(oldUser.getEmail())){
            if ((user.getEmail()==null || user.getEmail().equals(""))){

                model.addAttribute("errorEmail", errorEmail);
                return "profile";
            }
            if (!userService.checkEmail(user.getEmail())){
                model.addAttribute("errorEmail", errorUnicEmail);
                return "profile" ;
            }
        }
        if (!user.getPhoneNum().equals(oldUser.getPhoneNum())){

            if (!userService.checkPhone(user.getPhoneNum())){
                model.addAttribute("errorPhone", errorUnicPhone);
                return "profile";
            }
        }

        userService.saveUser(user);
        model.addAttribute("user", user);
        return "profile";
    }

    //новости
    @Autowired
    public void setNewService(NewService newService){
        this.newService = newService;
    }
    @GetMapping("/news")
    public String newsForm(@RequestParam(value = "name", required=false, defaultValue = "Unnamed") String name, Model model, Principal principal){

        Map<String, Object> map = new HashMap<String, Object>();
        model.addAttribute("news", newService.getAllNews());
        if (principal!=null)
            model.addAttribute("user", userService.getUserByLogin(principal.getName()));
        else
            model.addAttribute("user", new User());
        return "news";
    }
    @GetMapping("/news/newsDetails/{id}")
    public String newDetailsForm(Model model, @PathVariable("id") Long id, Principal principal){

        idNew = id;

        List<CommentNews> comments = new ArrayList<>();
        comments=newService.getCommentsNew(id);
        model.addAttribute("aNew", newService.getNewById(id));
        model.addAttribute("comments", comments);
        if (principal!=null)
            model.addAttribute("curUser", principal.getName());
        model.addAttribute("newComment", new CommentNews());
        if (principal!=null)
            model.addAttribute("user", userService.getUserByLogin(principal.getName()));
        else
            model.addAttribute("user", new User());
        return  "newsDetails";
    }
    public Long idNew = 0L;
    @PostMapping("/news/newsDetails")
    public String newDetailsForm (@ModelAttribute CommentNews comment, Model model, Principal principal){
        if (comment.getTextCom()!=null && !comment.getTextCom().equals("")){
            comment.setUser(userService.getUserByLogin(principal.getName()));
            comment.setaNew(newService.getNewById(idNew));
            comment.setDate(LocalDate.now());

            newService.saveCommentNew(comment);
        }


        List<CommentNews> comments = new ArrayList<>();
        comments=newService.getCommentsNew(idNew);

        model.addAttribute("aNew", newService.getNewById(idNew));
        model.addAttribute("comments", comments);
        if (principal!=null) {
            model.addAttribute("curUser", principal.getName());
            model.addAttribute("user", userService.getUserByLogin(principal.getName()));
        }
        else {
            model.addAttribute("curUser", "");
            model.addAttribute("user", new User());
        }

        model.addAttribute("newComment", new CommentNews());
        return "newsDetails";
    }
    @RequestMapping(value="/addNew", method= RequestMethod.GET)
    public String addNewForm(Model model, Principal principal){
        New aNew = new New();

        model.addAttribute("aNew", aNew);
        if (principal!=null)
            model.addAttribute("user", userService.getUserByLogin(principal.getName()));
        else
            model.addAttribute("user", new User());
        return "/addNew";
    }
    @RequestMapping(path = "/addNew", method = POST, consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
    public String addNewForm(Model model, Principal principal,
                             @ModelAttribute New aNew) throws IOException {
        if (aNew.getName()==null || aNew.getName().equals("")){
            model.addAttribute("errorName", errorName);
            return "addNew";
        }
        if (aNew.getFile()!=null){
            StringBuilder fileNames = new StringBuilder();
            MultipartFile file = aNew.getFile();
            Path resourceDirectory = Paths.get("src","main","resources", "static/news_images");
            Path fileNameAndPath = Paths.get(resourceDirectory.toAbsolutePath().toString(), file.getOriginalFilename());
            fileNames.append(file.getOriginalFilename());
            Files.write(fileNameAndPath, file.getBytes());
            aNew.setImage(file.getOriginalFilename());
        }else
            aNew.setImage("");

        aNew.setDate(LocalDate.now());
        aNew.setUser(userService.getUserByLogin(principal.getName()));
        newService.saveNew(aNew);

        model.addAttribute("aNew", aNew);
        return "news";
    }
    @GetMapping("/news/delete/{id}")
    public String deleteNewById(@PathVariable("id") Long id){
        newService.deleteNewById(id);
        return "redirect:/news";
    }


    //статьи о матчах
    @GetMapping("/articlesAboutMatch")
    public String articlesForm(@RequestParam(value = "name", required=false, defaultValue = "Unnamed") String name, Model model, Principal principal){

        model.addAttribute("arts", newService.getAllArticles());
        if (principal!=null)
            model.addAttribute("user", userService.getUserByLogin(principal.getName()));
        else
            model.addAttribute("user", new User());
        return "articlesAboutMatch";
    }
    @GetMapping("/articlesAboutMatch/articleDetails/{id}")
    public String articleDetailsForm(Model model, @PathVariable("id") Long id, Principal principal){

        idNew = id;

        List<CommentArticle> comments = new ArrayList<>();
        comments=newService.getCommentsArticle(id);
        model.addAttribute("art", newService.getArticleById(id));
        model.addAttribute("comments", comments);
        if (principal!=null)
            model.addAttribute("curUser", principal.getName());
        model.addAttribute("artComment", new CommentArticle());
        if (principal!=null)
            model.addAttribute("user", userService.getUserByLogin(principal.getName()));
        else
            model.addAttribute("user", new User());
        return  "articleDetails";
    }
    public Long idArticle = 0L;
    @PostMapping("/articlesAboutMatch/articleDetails")
    public String articleDetailsForm (@ModelAttribute CommentArticle comment, Model model, Principal principal){
        if (comment.getTextCom()!=null && !comment.getTextCom().equals("")) {
            comment.setUser(userService.getUserByLogin(principal.getName()));
            comment.setArticle(newService.getArticleById(idNew));
            comment.setDate(LocalDate.now());

            newService.saveCommentArticle(comment);
        }

        List<CommentArticle> comments = new ArrayList<>();
        comments=newService.getCommentsArticle(idNew);

        model.addAttribute("art", newService.getArticleById(idNew));
        model.addAttribute("comments", comments);
        if (principal!=null) {
            model.addAttribute("curUser", principal.getName());
            model.addAttribute("user", userService.getUserByLogin(principal.getName()));
        }
        else {
            model.addAttribute("curUser", "");
            model.addAttribute("user", new User());
        }
        model.addAttribute("artComment", new CommentNews());
        return "articleDetails";
    }
    @RequestMapping(value="/addArticle", method= RequestMethod.GET)
    public String addArticleForm(Model model, Principal principal){
        Article article = new Article();

        model.addAttribute("user", userService.getUserByLogin(principal.getName()));
        model.addAttribute("art", article);
        return "addArticle";
    }
    @RequestMapping(path = "/addArticle", method = POST, consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
    public String addArticleForm(Model model, Principal principal,
                             @ModelAttribute Article article) throws IOException {
        model.addAttribute("art", article);
        model.addAttribute("user", userService.getUserByLogin(principal.getName()));
        if (article.getName()==null || article.getName().equals("")){
            model.addAttribute("errorName", errorName);
            return "addArticle";
        }
        if (article.getDate()==null || article.getDate().equals("") || article.getDate().isAfter(LocalDate.now())){
            model.addAttribute("errorDate", errorDate);
            return "addArticle";
        }
        if (article.getNameTeam1()==null || article.getNameTeam1().equals("")){
            model.addAttribute("errorTeam1", errorNameT1);
            return "addArticle";
        }
        if (article.getScoreTeam1() == null || article.getScoreTeam1() > 3 || article.getScoreTeam1() < 0){
            model.addAttribute("errorTeam1", errorScoreT1);
            return "addArticle";
        }
        if (article.getNameTeam2() == null || article.getNameTeam2().equals("")){
            model.addAttribute("errorTeam2", errorNameT2);
            return "addArticle";
        }
        if (article.getScoreTeam2()==null || article.getScoreTeam2() > 3 ||
                article.getScoreTeam2() < 0 || article.getScoreTeam1() == article.getScoreTeam2()){
            model.addAttribute("errorTeam2", errorScoreT2);
            return "addArticle";
        }
        String str = article.getDesc();
        int scoreT1 = article.getScoreTeam1();
        int scoreT2 = article.getScoreTeam2();
        if (scoreT1>=3 && scoreT2<=2 && scoreT1>scoreT2)
            article.setDesc("Выиграла команда " + article.getNameTeam1() +
                    "\nС результатом " + scoreT1 + ":" + scoreT2 + "\n" + str);
        if (scoreT2>=3 && scoreT1<=2 && scoreT2>scoreT1)
            article.setDesc("Выиграла команда " + article.getNameTeam2() +
                    "\nС результатом" + scoreT2 + ":" + scoreT1 + "\n" + str);

        StringBuilder fileNames = new StringBuilder();
        MultipartFile file = article.getFile();

        if (!file.getOriginalFilename().equals("")){
            try {
                Path resourceDirectory = Paths.get("src","main","resources", "static/articles_images");
                Path fileNameAndPath = Paths.get(resourceDirectory.toAbsolutePath().toString(), file.getOriginalFilename());
                fileNames.append(file.getOriginalFilename());
                Files.write(fileNameAndPath, file.getBytes());
                article.setImage(file.getOriginalFilename());
            }catch (Exception ex){
                model.addAttribute("errorImage", ex.getMessage());
                return "addArticle";
            }

        }
        else{
            article.setImage("");
        }
        article.setUser(userService.getUserByLogin(principal.getName()));
        newService.saveArticle(article);

        return "profile";
    }
    @GetMapping("/articlesAboutMatch/delete/{id}")
    public String deleteArticleById(@PathVariable("id") Long id){
        newService.deleteArticleById(id);
        return "redirect:/articlesAboutMatch";
    }

}

