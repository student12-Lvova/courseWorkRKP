package com.example.lb61.models.news;

import com.example.lb61.models.UserRepository;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import org.springframework.jdbc.core.RowMapper;

public class CommentNewsMapper implements RowMapper<CommentNews> {
    private final JdbcTemplate jdbcTemplate;
    private UserRepository userRepository;
    private NewRepository newRepository;

    public CommentNewsMapper(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
        this.userRepository = new UserRepository(jdbcTemplate);
        this.newRepository = new NewRepository(jdbcTemplate);
    }

    @Override
    public CommentNews mapRow(ResultSet rs, int rowNum) throws SQLException {
        CommentNews commentNews = new CommentNews();
        commentNews.setId(Long.valueOf(rs.getString("id")));
        commentNews.setaNew(newRepository.findOne(Long.valueOf(rs.getString("idNew"))));
        commentNews.setUser(userRepository.findOne(Long.valueOf(rs.getString("idUser"))));
        commentNews.setTextCom(rs.getString("textCom"));
        commentNews.setDate(rs.getDate("date").toLocalDate());
        return commentNews;
    }
}
