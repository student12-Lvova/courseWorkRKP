
CREATE TABLE authorities (
username VARCHAR(50) NOT NULL,
authority VARCHAR(50) NOT NULL,
CONSTRAINT fk_authorities_users FOREIGN
KEY(username) REFERENCES Users(login)
);
CREATE UNIQUE INDEX ix_auth_idUser ON authorities
(username,authority);

INSERT into Users(login,password,email,phoneNum,enabled)
values ('user','pass','user@gmail.com','89000000000',true);
INSERT into Users(login,password,email,phoneNum,enabled)
values ('admin','pass','admin@gmail.com','89000000001',true);
INSERT into Users(login,password,email,phoneNum,enabled)
values ('newsman','pass','newsman@gmail.com','89000000002',true);
INSERT into Users(login,password,email,phoneNum,enabled)
values ('user1','pass','user1@gmail.com','89000000003',true);
INSERT into authorities values ('user','USER');
INSERT into authorities values ('admin','ADMIN');
INSERT into authorities values ('newsman','NEWSMAN');
INSERT into authorities values ('user1','USER');